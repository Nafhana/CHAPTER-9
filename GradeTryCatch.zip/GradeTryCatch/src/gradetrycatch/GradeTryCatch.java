package gradetrycatch;

import java.util.Scanner;
import java.util.InputMismatchException;

/**
 *
 * @author nafha
 */
public class GradeTryCatch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int grade;
        Scanner input = new Scanner(System.in);
        
        try {
            // User input their mark
            System.out.println("Enter your mark:");
            grade = input.nextInt();
            
            // Show their grade
            if (grade >= 70 && grade <= 100)
                System.out.println("Grade = A");
            else if (grade >= 60 && grade <= 69)
                System.out.println("Grade = B");
            else if (grade >= 50 && grade <= 59)
                System.out.println("Grade = C");
            else if (grade >= 45 && grade <= 49)
                System.out.println("Grade = D");
            else if (grade >= 40 && grade <= 44)
                System.out.println("Grade = E");
            else if (grade >= 0 && grade <= 39)
                System.out.println("Grade = FAIL");
            else
                System.out.println("Invalid data");
        } catch (InputMismatchException ime) {
            System.out.println("Please enter a valid number.");
        }
    }
}
